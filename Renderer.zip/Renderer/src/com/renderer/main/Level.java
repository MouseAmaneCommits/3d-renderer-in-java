package com.renderer.main;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.util.ArrayList;
import java.util.List;

public class Level
{
	private List<GameObject> gameObjects;
	
	public Level()
	{
		gameObjects = new ArrayList<GameObject>();
	}
	
	public void AddGameObject(GameObject gameObject)
	{
		gameObjects.add(gameObject);
	}
	
	public void Update()
	{
		for(GameObject gameObject : gameObjects)
		{
			gameObject.Update();
		}
	}
	
	public void Render(Graphics gtx)
	{
		for(GameObject gameObject : gameObjects)
		{
			gtx.drawImage(gameObject.sprite, gameObject.x, gameObject.y, new ImageObserver()
			{
				
				@Override
				public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height)
				{
					// TODO Auto-generated method stub
					return false;
				}
			});
		}
	}
}
