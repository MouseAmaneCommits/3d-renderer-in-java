package com.renderer.main;

import java.awt.Image;

public abstract class GameObject 
{
	protected int x,y;
	protected ID id;
	protected Image sprite;
	
	protected abstract void Update();
}
