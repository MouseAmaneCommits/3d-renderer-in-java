package com.renderer.main.objects;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.renderer.main.GameObject;
import com.renderer.main.ID;

public class Player extends GameObject
{
	public Player()
	{
		x = 0;
		y = 0;
		id = ID.Player;
		try
		{
			sprite = ImageIO.read(new File("res/player_idle.png"));
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	protected void Update()
	{
	}
}
