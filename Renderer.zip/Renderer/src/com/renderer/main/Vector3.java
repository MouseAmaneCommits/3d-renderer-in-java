package com.renderer.main;

public class Vector3
{
	public float x;
	public float y;
	public float z;
	
	public Vector3(float x, float y, float z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public Vector3()
	{
		this.x = 0;
		this.y = 0;
		this.z = 0;
	}
	
	public static Vector3 ConvertVector3ToRenderingSpace(int width, int height, Vector3 vector)
	{
		Vector3 w = new Vector3();
		w.x = (int)(width / 2 + vector.x);
		w.y = (int)(height / 2 - vector.y);
		
		return w;
	}
	
	public static void PrintVector(Vector3 vector)
	{
		System.out.println("(" + vector.x + ", " + vector.y + ", " + vector.z);
	}
}