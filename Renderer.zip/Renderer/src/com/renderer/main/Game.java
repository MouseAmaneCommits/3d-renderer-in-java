package com.renderer.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferStrategy;

import com.renderer.main.objects.Player;

public class Game extends Canvas implements Runnable
{
	private static final long serialVersionUID = 1L;
	
	public static final int WIDTH = 1280;
	public static final int HEIGHT = 720;
	public static final String TITLE = "3D Renderer";
	
	private Vector3[] points = new Vector3[8];
	
	private float a = 1.3f;
	private float k = 1.0f;
	
	private Thread thread;
	private boolean running = false;
	private float fps;
	//private Level myLevel;
	
	public Game()
	{
		
		points[0] = new Vector3(-50, -50, -50);
		points[1] = new Vector3(-50, 50, -50);
		points[2] = new Vector3(50, 50, -50);
		points[3] = new Vector3(50, -50, -50);

		points[4] = new Vector3(-50, -50, 50);
		points[5] = new Vector3(-50, 50, 50);
		points[6] = new Vector3(50, 50, 50);
		points[7] = new Vector3(50, -50, 50);
		
		new Window(WIDTH, HEIGHT, TITLE, this);
	}
	
	public void run() 
	{
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		
		while(running)
		{
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta >= 1)
			{
				Tick();
				delta--;
			}
			if(running)
			{
				Render();
			}
			frames++;
			
			if(System.currentTimeMillis() - timer > 1000)
			{
				timer += 1000;
				fps = frames;
				frames = 0;
			}
		}
		Stop();
	}
	
	private void Tick()
	{
		
	}
	
	private float angle = 0;
	
	private void Render()
	{
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null)
		{
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics2D gtx = (Graphics2D)bs.getDrawGraphics();
		
		gtx.setColor(Color.pink);
		gtx.fillRect(0, 0, WIDTH, HEIGHT);
		
		gtx.setColor(Color.white);
		angle -= 0.0001f;
		//angle = 1f;
		
		  float[][] rotationMatrixX =
			  {
			    {1, 0, 0},
			    {0, (float) Math.cos(angle), (float) -Math.sin(angle)},
			    {0, (float) Math.sin(angle), (float) Math.cos(angle)}
			  };
		  
		  // 3d rendering test in java!
			  
			  float[][] rotationMatrixY =
			  {
			    {(float) Math.cos(angle), 0, (float) Math.sin(angle)},
			    {0, 1, 0},
			    {(float) -Math.sin(angle), 0, (float) Math.cos(angle)}
			  };
			  //k -= 0.00005f;
			  
			  float[][] strechMatrixX =
				  {
						  {k, 0, 0},
						  {0, 1, 0},
						  {0, 0, 0}
				  };
			  
	    Vector3[] projected = new Vector3[8];
		
	    
	    int index = 0;
		for(Vector3 point : points)
		{	
			float[][] rotatedMatrixY = Matrix.Multiply(rotationMatrixY, Matrix.ConvertVectorToMatrix(point));
			float[][] rotatedMatrix = Matrix.Multiply(rotationMatrixX, rotatedMatrixY);
			float[][] screchedMatrix = Matrix.Multiply(strechMatrixX, rotatedMatrix);
			
			Vector3 mat = Matrix.ConvertMatrixToVector3(screchedMatrix);
			
			float distance = 1.0f;
			float z = 1 / (distance - mat.z);
			
			float[][] projection = 
				{
					{z, 0, 0},
					{0, z, 0}
				};
			
			float[][] projectedMatrix = Matrix.Multiply(projection, screchedMatrix);
			
			Vector3 myVec = Vector3.ConvertVector3ToRenderingSpace(WIDTH, HEIGHT,
					Matrix.ConvertMatrixToVector3(projectedMatrix));
			
			//Vector3.PrintVector(myVec);
			
			projected[index] = myVec;
			
			index++;
		}
		
		  // Connect edges
		  for(int i = 0; i < (points.length/2); i++)
		  {
			  int i1x = i;
			  int i1y = (i+1) % (points.length/2);
			  
			  int i2x = i + (points.length/2);
			  int i2y = ((i+1) % (points.length/2))+(points.length/2);
			  
			  int i3x = i;
			  int i3y = i + (points.length/2);
			
			  gtx.setColor(Color.yellow);
			  Connect(gtx, i1x, i1y, projected);
			  gtx.setColor(Color.green);
			  Connect(gtx, i2x, i2y, projected);
			  gtx.setColor(Color.blue);
			  Connect(gtx, i3x, i3y, projected);
		  }
		  
		  gtx.setFont(new Font("Times new roman", Font.PLAIN, 24));
		  gtx.drawString("FPS: " + fps, 5, 20);
		
		
		
		gtx.dispose();
		bs.show();
	}
	
	void Connect(Graphics gtx, int i, int j, Vector3[] pts)
	{
		Vector3 a = pts[i];
		Vector3 b = pts[j];
		
		gtx.drawLine((int)a.x, (int)a.y, (int)b.x, (int)b.y);
		
		//gizmos thing
		gtx.fillRect((int)a.x, (int)a.y, 10, 10);
	}
	
	void Connect(Graphics gtx, int i, int j, Vector4[] pts)
	{
		Vector4 a = pts[i];
		Vector4 b = pts[j];
		
		gtx.drawLine((int)a.x, (int)a.y, (int)b.x, (int)b.y);
		
		//gizmos thing
		gtx.fillRect((int)a.x, (int)a.y, 10, 10);
	}
	
	public synchronized void Start()
	{
		thread = new Thread(this);
		running = true;
		thread.start();
	}
	
	public synchronized void Stop()
	{
		try
		{
			thread.join();
			running = false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String args[])
	{
		new Game();
	}
}
