package com.renderer.main;

public enum ID
{
	Player
}
